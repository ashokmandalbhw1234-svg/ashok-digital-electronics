ASHOK DIGITAL ELECTRONICS — JELLY PRO PREMIUM ZIP

इस ZIP में:
- index.html — वेबसाइट
- style.css — Jelly / Glassmorphism डिजाइन
- script.js — Search, filters, product manager, photo preview, WhatsApp enquiry

खोलने के लिए:
1. ZIP पर Right-click > Extract All.
2. तीनों फाइलें एक ही फोल्डर में रखें.
3. index.html पर double-click करके Chrome में देखें.

प्रोडक्ट फोटो जोड़ना (डेमो/लोकल):
1. वेबसाइट खोलें और “Manage products” पर क्लिक करें.
2. Product name, category, price/description भरें.
3. Product photo में अपने कंप्यूटर से JPG/PNG/WebP चुनें.
4. Save product दबाएँ.
इस डेमो में प्रोडक्ट और फोटो केवल उसी ब्राउज़र के localStorage में सेव होते हैं; दूसरे कंप्यूटर या लाइव वेबसाइट पर अपने-आप नहीं दिखते। लाइव GitHub Pages के लिए फोटो फाइल को repository में जोड़ना या image hosting/backend लगाना होगा.

महत्वपूर्ण:
- यह एक नया frontend starter है. पुराना Firebase order-saving code इसमें merge नहीं किया गया, क्योंकि वास्तविक source HTML/JS उपलब्ध नहीं था.
- WhatsApp enquiry buttons काम करते हैं; Firebase में order save होना configured नहीं है.
- WhatsApp number script.js में 917739778039 है; publish करने से पहले पुष्टि करें.
- दुकान का पता: Bengali Para, Barharwa, Jharkhand 816101, Near Sarvajanik Mansa Mandir. पुष्टि करके प्रकाशित करें.
- कीमत/stock की पुष्टि करके ही लिखें.
- Google Fonts इंटरनेट से लोड होते हैं.
